# zksnark-standards

This repo contains EIPs for two standards relating to zk-SNARK verification:

- zk-SNARK 'Verifier' standard
- zk-SNARK 'Verifier Registry' standard

# implementations

Please see the example implementations and test scripts in this repo.

